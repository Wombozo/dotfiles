#!/usr/bin/env sh
cp "$@" ~/dotfiles/wallpaper.jpg
feh --bg-scale ~/dotfiles/wallpaper.jpg
